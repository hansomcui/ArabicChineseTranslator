# V10 Free MyVoice：电脑端一次性设置

V10 不再使用 ElevenLabs，也不需要按字符付费。手机 App 有两种朗读模式：

- **没有电脑服务器时**：自动使用 Android 手机自带中文 TTS，永久免费。
- **电脑开启 GPT-SoVITS 时**：自动用你的本人音色朗读翻译后的中文。

## 1. 启动 GPT-SoVITS API

在 GPT-SoVITS 目录中运行：

```bash
python api_v2.py -a 0.0.0.0 -p 9880
```

官方 API 的 `/tts` 接口默认需要：中文文本、参考音频路径、参考文本和语言。

## 2. 安装 Gateway 依赖

在 GPT-SoVITS 的 Python 环境中运行：

```bash
pip install fastapi uvicorn requests python-multipart
```

确保电脑上可以执行 `ffmpeg`。GPT-SoVITS 一键环境通常已经包含。

## 3. 启动 MyVoice Gateway

把 `myvoice_gateway.py` 放在电脑任意目录，运行：

```bash
python myvoice_gateway.py
```

默认地址：

```text
http://0.0.0.0:9879
```

Gateway 会把手机录的 M4A 声音样本转换为 WAV，并调用本机 `http://127.0.0.1:9880/tts`。

## 4. 手机设置

确保手机和电脑在同一个 Wi‑Fi / 局域网。

Windows 命令行运行：

```bat
ipconfig
```

找到电脑 IPv4，例如：

```text
192.168.1.100
```

在 V10 App 中填：

```text
http://192.168.1.100:9879
```

然后按 App 提示，朗读固定中文句子 8–12 秒并上传。以后每句阿语翻译完成后，会优先用 GPT-SoVITS 生成你的声音；电脑没开、网络断开或服务器失败时，会自动退回手机系统中文 TTS。

## 5. Windows 防火墙

第一次运行时允许 Python 在“专用网络”通信。若手机连接不到，检查 TCP 9879 端口是否允许。

## 安全

这个 Gateway 默认没有账号密码，设计用于你自己的局域网。不要把 9879 端口直接暴露到公网。
