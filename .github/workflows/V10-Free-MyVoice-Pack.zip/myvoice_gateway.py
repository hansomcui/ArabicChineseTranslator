#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
V10 Free MyVoice Gateway
Runs beside GPT-SoVITS and provides:
  GET  /health
  POST /upload_ref   multipart: file + prompt_text
  POST /tts          JSON: text + ref_audio_path + prompt_text

Default GPT-SoVITS API: http://127.0.0.1:9880
Default gateway listen: 0.0.0.0:9879
"""

import os
import shutil
import subprocess
import uuid
from pathlib import Path

import requests
import uvicorn
from fastapi import FastAPI, File, Form, HTTPException, UploadFile
from fastapi.responses import JSONResponse, Response
from pydantic import BaseModel

GPT_SOVITS_URL = os.environ.get("GPT_SOVITS_URL", "http://127.0.0.1:9880").rstrip("/")
HOST = os.environ.get("MYVOICE_HOST", "0.0.0.0")
PORT = int(os.environ.get("MYVOICE_PORT", "9879"))

BASE_DIR = Path(__file__).resolve().parent
REF_DIR = BASE_DIR / "myvoice_refs"
REF_DIR.mkdir(parents=True, exist_ok=True)

app = FastAPI(title="V10 Free MyVoice Gateway")


class TTSBody(BaseModel):
    text: str
    ref_audio_path: str
    prompt_text: str = ""


@app.get("/health")
def health():
    return {
        "ok": True,
        "gateway": "V10 Free MyVoice",
        "gpt_sovits_url": GPT_SOVITS_URL,
    }


@app.post("/upload_ref")
async def upload_ref(
    file: UploadFile = File(...),
    prompt_text: str = Form(""),
):
    suffix = Path(file.filename or "sample.m4a").suffix or ".m4a"
    token = uuid.uuid4().hex
    src = REF_DIR / f"{token}{suffix}"
    wav = REF_DIR / f"{token}.wav"

    with src.open("wb") as f:
        while True:
            chunk = await file.read(1024 * 1024)
            if not chunk:
                break
            f.write(chunk)

    # GPT-SoVITS reference audio is most reliable as mono WAV.
    ffmpeg = shutil.which("ffmpeg")
    if not ffmpeg:
        src.unlink(missing_ok=True)
        raise HTTPException(
            status_code=500,
            detail="ffmpeg not found. Install ffmpeg or use the GPT-SoVITS one-click environment."
        )

    cmd = [
        ffmpeg, "-y", "-i", str(src),
        "-ac", "1",
        "-ar", "32000",
        "-c:a", "pcm_s16le",
        str(wav),
    ]
    proc = subprocess.run(cmd, capture_output=True, text=True)
    src.unlink(missing_ok=True)

    if proc.returncode != 0 or not wav.exists():
        raise HTTPException(
            status_code=500,
            detail="Audio conversion failed: " + proc.stderr[-1000:]
        )

    return JSONResponse({
        "ok": True,
        "ref_audio_path": str(wav.resolve()),
        "prompt_text": prompt_text,
    })


@app.post("/tts")
def tts(body: TTSBody):
    if not body.text.strip():
        raise HTTPException(status_code=400, detail="text is empty")

    ref = Path(body.ref_audio_path)
    if not ref.exists():
        raise HTTPException(
            status_code=400,
            detail=f"Reference audio does not exist on server: {ref}"
        )

    payload = {
        "text": body.text,
        "text_lang": "zh",
        "ref_audio_path": str(ref),
        "prompt_text": body.prompt_text,
        "prompt_lang": "zh",
        "text_split_method": "cut5",
        "batch_size": 1,
        "speed_factor": 1.0,
        "media_type": "wav",
        "streaming_mode": False,
    }

    try:
        r = requests.post(
            GPT_SOVITS_URL + "/tts",
            json=payload,
            timeout=120,
        )
    except requests.RequestException as e:
        raise HTTPException(
            status_code=502,
            detail=f"Cannot connect to GPT-SoVITS at {GPT_SOVITS_URL}: {e}"
        )

    if r.status_code < 200 or r.status_code >= 300:
        detail = r.text[:2000]
        raise HTTPException(
            status_code=502,
            detail=f"GPT-SoVITS error {r.status_code}: {detail}"
        )

    return Response(content=r.content, media_type="audio/wav")


if __name__ == "__main__":
    print("V10 Free MyVoice Gateway")
    print(f"GPT-SoVITS: {GPT_SOVITS_URL}")
    print(f"Gateway: http://{HOST}:{PORT}")
    uvicorn.run(app, host=HOST, port=PORT)
